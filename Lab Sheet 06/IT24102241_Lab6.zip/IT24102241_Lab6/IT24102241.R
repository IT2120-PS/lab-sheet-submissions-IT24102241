setwd("D:\\SLIIT\\2nd year 1 sem\\PS\\Lab\\IT24102241_Lab6")

#Q1
#X∼Binomial(n=50,p=0.85)
#Q2
#P(X≥47)=1−P(X≤46)
n <- 50
p <- 0.85
prob <- 1 - pbinom(46,n,p)
prob

#Q2
#Part 1
# X=number of calls received in one hour
#Part 2
#X∼Poisson(λ=12)
#Part 3
lambda <- 12
prob <- dpois(15,lambda)
prob
