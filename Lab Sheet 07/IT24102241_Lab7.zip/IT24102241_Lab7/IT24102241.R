setwd("D:\\SLIIT\\2nd year 1 sem\\PS\\Lab\\IT24102241_Lab7")

# Question 1
# X follows uniform distribution between 0 and 40 minutes
prob_train <- punif(25, min=0, max=40, lower.tail=TRUE) - punif(10, min=0, max=40, lower.tail=TRUE)
print(prob_train)

# Question 2
# X follows exponential distribution with rate = 1/3(at most 2)
prob_update <- pexp(2, rate=1/3, lower.tail=TRUE)
print(prob_update)

# Question 3
# 3-1
prob_iq_above_130 <- 1 - pnorm(130, mean=100, sd=15, lower.tail=TRUE)
print(prob_iq_above_130)

# 3-2
iq_95th_percentile <- qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)
print(iq_95th_percentile)
